=====================================
  PROXY FORWARDER - INSTALLATION GUIDE
=====================================

SYSTEM REQUIREMENTS:
- Windows 10/11 (64-bit)
- .NET 8 Runtime (included in this package)
- Administrator privileges for installation

INSTALLATION STEPS:

1. Extract the ZIP file to a temporary folder
2. Right-click "INSTALL.bat" and select "Run as Administrator"
3. Follow the on-screen instructions
4. The app will be installed to: C:\Program Files\ProxyForwarder

LAUNCHING THE APPLICATION:

After installation, you can start ProxyForwarder from:
- Start Menu: Search for "ProxyForwarder"
- Desktop: Double-click the ProxyForwarder shortcut
- Command Line: C:\Program Files\ProxyForwarder\ProxyForwarder.App.exe

WHAT IS PROXY FORWARDER?

Proxy Forwarder transforms upstream proxies (HOST:PORT:USER:PASS) into local 
forwarders on 127.0.0.1:<port>. It provides:

- HTTP proxy chaining without SSL MITM
- Secure credential storage
- Automatic port allocation
- DNS leak prevention
- Latency monitoring and IP geolocation

UNINSTALLATION:

To uninstall, manually delete the folder:
C:\Program Files\ProxyForwarder

And remove shortcuts from:
- Start Menu > Programs > ProxyForwarder
- Desktop (if created)

TROUBLESHOOTING:

If the installer fails:
- Ensure you run it as Administrator
- Check that Windows Defender or antivirus isn't blocking it
- Verify you have sufficient disk space

For more help, see the application's Help menu.
